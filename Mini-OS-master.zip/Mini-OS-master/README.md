# Mini-OS
A mini project made in JAVA as course project in Operating System.
Project is made using NetBeans. Import the project and run the Home.java file to start the application.
